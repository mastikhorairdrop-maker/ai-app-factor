package com.maya.assistant.automation

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.maya.assistant.MayaApplication
import com.maya.assistant.service.MayaAccessibilityService
import kotlinx.coroutines.delay

class AutomationEngine(private val service: MayaAccessibilityService) {

    fun findNode(root: AccessibilityNodeInfo?, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (root == null) return null
        if (predicate(root)) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNode(child, predicate)
            if (found != null) return found
        }
        return null
    }

    suspend fun waitForNode(timeoutMs: Long = 6000, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (AutomationLogBus.isStopped()) return null
            val found = findNode(service.rootInActiveWindow, predicate)
            if (found != null) return found
            delay(250)
        }
        return null
    }

    suspend fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null || AutomationLogBus.isStopped()) return false
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            delay(250); return true
        }
        // Fallback: Dispatch Gesture tap at center coordinates
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (!bounds.isEmpty) {
            return service.dispatchClick(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        }
        return false
    }

    suspend fun setText(node: AccessibilityNodeInfo?, text: String): Boolean {
        if (node == null || AutomationLogBus.isStopped()) return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            delay(200); return true
        }
        // Clipboard paste fallback
        val clip = ClipData.newPlainText("maya", text)
        val cm = MayaApplication.instance.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(clip)
        return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }
}
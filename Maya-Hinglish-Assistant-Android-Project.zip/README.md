# 🌸 Maya - Hinglish Phone AI Voice Assistant

A complete compile-ready native Android app delivering sweet young female Hinglish voice assistance and phone automation via AccessibilityService.

### Setup Instructions
1. Get a Gemini API Key from Google AI Studio.
2. Enable Accessibility Service for Maya in Android Settings.
3. On Android 13/14, enable "Allow restricted settings" from App Info menu.
4. Run './gradlew assembleDebug' or push to GitHub to trigger '.github/workflows/build.yml'.